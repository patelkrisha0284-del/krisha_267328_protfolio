# Krisha Patel — Personal Portfolio

A responsive personal portfolio website built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling, hover effects and dark theme styles
- `script.js` — mobile menu, dark mode and contact form validation
- `assets/krisha-profile.jpg` — profile photo taken from the supplied portfolio image

## Run locally
Open `index.html` in a browser. No build tools or dependencies are required.

## Before publishing
- Review the contact details and decide which ones you want public.
- Replace the sample practice-project descriptions with your own finished projects when you have them.
- The contact form validates the fields and opens the visitor's default email app; it does not store or send messages through a server.

## Publish with GitHub Pages
1. Create a new public repository on GitHub, for example `krisha-patel-portfolio`.
2. Upload all files and the `assets` folder, keeping the same folder structure.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. After GitHub Pages publishes the site, copy the website URL from the Pages section and share your repository link.
